normal
1
16
sc
10.0
1.0e-5
P8-7_D3_3.xyz
